package com.viscouspot.gitsync.widget

import HomeWidgetGlanceWidgetReceiver

class ForceSyncWidgetReceiver : HomeWidgetGlanceWidgetReceiver<ForceSyncWidget>() {
  override val glanceAppWidget = ForceSyncWidget()
}