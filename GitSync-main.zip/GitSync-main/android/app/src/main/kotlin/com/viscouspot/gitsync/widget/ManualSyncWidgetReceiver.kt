package com.viscouspot.gitsync.widget

import HomeWidgetGlanceWidgetReceiver

class ManualSyncWidgetReceiver : HomeWidgetGlanceWidgetReceiver<ManualSyncWidget>() {
  override val glanceAppWidget = ManualSyncWidget()
}