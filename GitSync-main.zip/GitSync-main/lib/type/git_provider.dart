enum GitProvider { GITHUB, GITEA, GITLAB, HTTPS, SSH }
