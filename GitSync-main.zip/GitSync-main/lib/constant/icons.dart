import 'package:flutter/material.dart';

const IconData gitea_logo = IconData(0xe800, fontFamily: "GiteaLogo", fontPackage: null);
const IconData gitlab_logo = IconData(0xe800, fontFamily: "GitlabLogo", fontPackage: null);
