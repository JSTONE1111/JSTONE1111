import WidgetKit
import SwiftUI

@main
struct ForceSyncWidgetBundle: WidgetBundle {
    var body: some Widget {
        ForceSyncWidget()
    }
}
